r = float(input("Raio: "))

print("Área = ",3.14159*(r**2))
