b = float(input("Quanto mede a largura do terreno? R:"))
h = float(input("Quanto mede o cumprimento do terreno? R:"))
print("O terreno tem ",b*h,"m²")
