r = float(input("Raio: "))
h = float(input("Altura: "))

print("Volume = ",(3.14159*r)/(2*h))
