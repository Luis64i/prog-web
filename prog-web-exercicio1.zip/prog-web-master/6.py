n = input("Digite um número: ")
print("O número informado foi ",n)
