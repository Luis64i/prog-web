c = int(input("Quantos cavalos foram comprados? R:"))
print("São necessárias ",4*c," ferraduras para equipar os ",c, "cavalos5")
