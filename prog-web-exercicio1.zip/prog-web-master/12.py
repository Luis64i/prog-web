a = int(input("Digite um número: "))
b = int(input("Digite outro número: "))
print ("O resto da divisão entre esses números é ",a % b)
