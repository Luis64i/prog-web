x = int(input("Primeiro Número: "))
y = int(input("Segundo Número: "))
print("Soma: ",x+y)
