try:
    a = float(input('Salário: '))
    print('Mais 15%: ', a*1.15) 
except:
    print('Você digitou algo errado.')
