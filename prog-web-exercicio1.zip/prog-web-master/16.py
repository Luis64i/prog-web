valor = float(input("Digite o valor: "))
taxa = float(input("Digite a taxa: "))
tempo = float(input("Digite o tempo: "))
print ("Prestação = ", (valor+(valor*(taxa/100)))/tempo)
