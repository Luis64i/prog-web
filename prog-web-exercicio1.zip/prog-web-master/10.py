try:
    a = int(input('Digite um valor: '))
    print('O dobro do que você digitou: ', a*2) 
except:
    print('Você digitou algo errado.')
