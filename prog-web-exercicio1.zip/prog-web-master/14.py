a = int(input("A = "))
b = int(input("B = "))
c = a
a = b
b = c

