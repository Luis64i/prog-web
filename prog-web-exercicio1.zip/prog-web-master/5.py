print ("Alô Mundo")
