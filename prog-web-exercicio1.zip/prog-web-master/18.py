a = int(input("Digite o valor de A: "))
b = int(input("Digite o valor de B: "))
c = int(input("Digite o valor de C: "))
d = int(input("Digite o valor de D: "))
e = int(input("Digite o valor de E: "))
x = int(input("Digite o valor de x: "))
p = (a*(x**4))+(b*(x**3))+(c*(x**2))+(d*x)+e
print ("P(x) = ",p)
