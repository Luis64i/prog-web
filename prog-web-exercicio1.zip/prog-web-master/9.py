a = int(input("Digite um número: "))
b = int(input("Digite outro número: "))
print ("O produto desses números é ",a * b)
