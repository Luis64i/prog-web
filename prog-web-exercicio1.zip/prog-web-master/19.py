c = float(input("Temperatua em Cº: "))
f = (9*c+160)/5
print("Temperatura em Fahrenheit: ",f)
