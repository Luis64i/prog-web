c = float(input("Quantos reais valem 1 dólar(cotação)? R: "))
d = float(input("Quantos dólares deseja converter? R: "))
print(d," dólares correspondem a ",d*c," reais na cotação de ",c," reais por dólar")
